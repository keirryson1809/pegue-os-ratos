let cat;
let rats = [];
let score = 0;
let maxRats = 5;

function setup() {
  createCanvas(800, 600);
  cat = new Cat(width / 2, height / 2);

  for (let i = 0; i < maxRats; i++) {
    rats.push(new Rat(random(width), random(height)));
  }
}

function draw() {
  background(220, 220, 200);

  // Desenha o chão
  fill(180, 150, 100);
  rect(0, height - 100, width, 100);

  // Atualiza e mostra o gato
  cat.update();
  cat.show();

  // Atualiza e mostra os ratos
  for (let i = rats.length - 1; i >= 0; i--) {
    rats[i].update();
    rats[i].show();

    // Verifica colisão com o gato
    if (cat.catchRat(rats[i])) {
      rats.splice(i, 1);
      score++;

      // Adiciona novo rato para manter o jogo contínuo
      rats.push(new Rat(random(width), random(height - 100)));
    }
  }

  // Mostra a pontuação
  fill(0);
  textSize(24);
  text("Ratos pegos: " + score, 10, 30);
}

// Classe do gato
class Cat {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 60;
    this.speed = 5;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    // Limita o gato dentro da tela
    this.x = constrain(this.x, this.size / 2, width - this.size / 2);
    this.y = constrain(this.y, this.size / 2, height - 100 - this.size / 2);
  }

  show() {
    push();
    translate(this.x, this.y);

    // Corpo do gato
    fill(150, 100, 50);
    ellipse(0, 0, this.size * 1.2, this.size);

    // Cabeça
    ellipse(0, -this.size * 0.6, this.size, this.size * 0.9);

    // Orelhas
    fill(120, 80, 40);
    triangle(-this.size * 0.3, -this.size * 1.1, -this.size * 0.1, -this.size * 1.5, 0, -this.size * 1.1);
    triangle(this.size * 0.3, -this.size * 1.1, this.size * 0.1, -this.size * 1.5, 0, -this.size * 1.1);

    // Olhos
    fill(0);
    ellipse(-this.size * 0.2, -this.size * 0.7, this.size * 0.2, this.size * 0.2);
    ellipse(this.size * 0.2, -this.size * 0.7, this.size * 0.2, this.size * 0.2);

    pop();
  }

  catchRat(rat) {
    let d = dist(this.x, this.y, rat.x, rat.y);
    return d < (this.size + rat.size) / 2 * 0.8;
  }
}

// Classe do rato
class Rat {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 30;
    this.speed = random(1, 3);
    this.direction = p5.Vector.random2D();
  }

  update() {
    this.x += this.direction.x * this.speed;
    this.y += this.direction.y * this.speed;

    // Muda direção aleatoriamente
    if (random() < 0.02) {
      this.direction = p5.Vector.random2D();
    }

    // Mantém dentro da área do chão
    this.x = constrain(this.x, this.size / 2, width - this.size / 2);
    this.y = constrain(this.y, this.size / 2, height - 100 - this.size / 2);
  }

  show() {
    push();
    translate(this.x, this.y);

    // Corpo do rato
    fill(100);
    ellipse(0, 0, this.size * 1.5, this.size);

    // Cabeça
    ellipse(this.size * 0.4, 0, this.size * 0.8, this.size * 0.8);

    // Orelhas
    fill(150);
    ellipse(this.size * 0.6, -this.size * 0.3, this.size * 0.3, this.size * 0.3);
    ellipse(this.size * 0.6, this.size * 0.3, this.size * 0.3, this.size * 0.3);

    // Olhos
    fill(0);
    ellipse(this.size * 0.5, -this.size * 0.1, this.size * 0.15, this.size * 0.15);

    pop();
  }
}
